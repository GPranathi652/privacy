# HealthSecure - Secure Healthcare Web Application

HealthSecure is a full-stack healthcare web application built with React (frontend) and FastAPI with MongoDB (backend). The application provides secure data management with encryption for personal data, machine learning insights for health data, and role-based access control.

## Features

- **Secure Authentication**: JWT-based authentication with user and hospital roles
- **Data Classification**: Automatic classification of personal vs. health data
- **Encrypted Personal Data**: AES-256 encryption for all personal information
- **ML-Powered Insights**: Health risk predictions based only on health data
- **Role-Based Access Control**: Hospitals can only access health data, not personal details
- **Responsive Design**: Works on mobile, tablet, and desktop devices

## Tech Stack

### Frontend
- React with TypeScript
- React Router for navigation
- React Hook Form for form handling
- Tailwind CSS for styling
- Framer Motion for animations
- Axios for API requests
- Lucide React for icons

### Backend
- FastAPI (Python)
- MongoDB with Motor (async driver)
- JWT for authentication
- AES-256 encryption for personal data
- Scikit-learn for machine learning
- Pydantic for data validation

## Getting Started

### Prerequisites
- Node.js (v16+)
- Python (3.8+)
- MongoDB

### Installation

1. Clone the repository
```bash
git clone https://github.com/your-username/healthsecure.git
cd healthsecure
```

2. Install frontend dependencies
```bash
npm install
```

3. Install backend dependencies
```bash
cd backend
pip install -r requirements.txt
```

4. Start MongoDB (if not running)
```bash
mongod
```

5. Run the backend server
```bash
cd backend
uvicorn main:app --reload
```

6. In a new terminal, run the frontend
```bash
npm run dev
```

7. Open your browser and navigate to http://localhost:5173

## Project Structure

```
healthsecure/
├── public/               # Public assets
├── src/                  # Frontend source code
│   ├── components/       # Reusable UI components
│   ├── contexts/         # React contexts (auth, etc.)
│   ├── pages/            # Application pages
│   ├── types/            # TypeScript type definitions
│   ├── utils/            # Utility functions
│   ├── App.tsx           # Main App component
│   └── main.tsx          # Entry point
├── backend/              # Backend source code
│   ├── main.py           # FastAPI application
│   └── requirements.txt  # Python dependencies
└── README.md             # Project documentation
```

## Security Features

- **JWT Authentication**: Secure token-based authentication
- **Password Hashing**: Secure password storage with bcrypt
- **AES-256 Encryption**: Military-grade encryption for personal data
- **Data Classification**: Automatic separation of personal and health data
- **Role-Based Access**: Strict access controls based on user role
- **CORS Protection**: Configure allowed origins
- **Error Handling**: Secure error messages

## License

This project is licensed under the MIT License