import React from 'react';
import { Link } from 'react-router-dom';
import { Shield, Lock, Activity, Database, Server, Brain } from 'lucide-react';
import Button from '../components/ui/Button';
import Layout from '../components/layout/Layout';
import { motion } from 'framer-motion';

const Home: React.FC = () => {
  const features = [
    {
      icon: <Lock className="h-6 w-6 text-primary-500" />,
      title: 'End-to-End Encryption',
      description: 'Your personal data is encrypted with AES-256, ensuring your information remains private even from us.'
    },
    {
      icon: <Database className="h-6 w-6 text-primary-500" />,
      title: 'Data Classification',
      description: 'Automatic separation of personal and health data, allowing authorized parties to access only what they need.'
    },
    {
      icon: <Brain className="h-6 w-6 text-primary-500" />,
      title: 'ML-Powered Insights',
      description: 'Get personalized health insights and risk assessments based on your health data without exposing personal details.'
    },
    {
      icon: <Server className="h-6 w-6 text-primary-500" />,
      title: 'Secure Hospital Access',
      description: 'Grant healthcare providers access to your health data while keeping personal information encrypted and private.'
    }
  ];
  
  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: 0.1 * i,
        duration: 0.5,
      }
    })
  };
  
  return (
    <Layout>
      {/* Hero Section */}
      <div className="bg-gradient-to-b from-primary-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-20">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <motion.h1 
                className="text-4xl sm:text-5xl font-bold text-neutral-900 leading-tight"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                Secure Healthcare,<br />
                <span className="text-primary-600">Private by Design</span>
              </motion.h1>
              <motion.p 
                className="mt-4 text-xl text-neutral-600"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
              >
                HealthSecure protects your personal data with military-grade encryption while enabling ML-powered insights for better health outcomes.
              </motion.p>
              <motion.div 
                className="mt-8 flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <Link to="/register">
                  <Button size="lg">Get Started</Button>
                </Link>
                <Link to="/about">
                  <Button variant="outline" size="lg">Learn More</Button>
                </Link>
              </motion.div>
            </div>
            <motion.div 
              className="flex justify-center"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <div className="w-full max-w-md bg-white p-6 rounded-xl shadow-lg relative">
                <div className="absolute top-0 right-0 transform translate-x-1/4 -translate-y-1/4">
                  <Shield className="h-20 w-20 text-primary-500 opacity-20" />
                </div>
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold">Health Data</h3>
                    <span className="health-badge px-2 py-0.5 bg-secondary-100 text-secondary-800 text-xs rounded-full">
                      Health Info
                    </span>
                  </div>
                  <div className="space-y-2">
                    <div className="p-2 bg-neutral-50 rounded-md flex justify-between">
                      <span className="text-neutral-600">Blood Pressure</span>
                      <span className="font-medium">120/80 mmHg</span>
                    </div>
                    <div className="p-2 bg-neutral-50 rounded-md flex justify-between">
                      <span className="text-neutral-600">Heart Rate</span>
                      <span className="font-medium">72 bpm</span>
                    </div>
                    <div className="p-2 bg-neutral-50 rounded-md flex justify-between">
                      <span className="text-neutral-600">Glucose</span>
                      <span className="font-medium">90 mg/dL</span>
                    </div>
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold">Personal Info</h3>
                    <span className="encrypted-badge px-2 py-0.5 bg-accent-100 text-accent-800 text-xs rounded-full">
                      Encrypted
                    </span>
                  </div>
                  <div className="space-y-2">
                    <div className="p-2 bg-neutral-50 rounded-md flex justify-between">
                      <span className="text-neutral-600">Full Name</span>
                      <span className="font-medium">••••••••••</span>
                    </div>
                    <div className="p-2 bg-neutral-50 rounded-md flex justify-between">
                      <span className="text-neutral-600">ID Number</span>
                      <span className="font-medium">••••••••••</span>
                    </div>
                    <div className="p-2 bg-neutral-50 rounded-md flex justify-between">
                      <span className="text-neutral-600">Address</span>
                      <span className="font-medium">••••••••••</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
      
      {/* Features Section */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-neutral-900">Secure Healthcare Platform</h2>
            <p className="mt-4 max-w-2xl mx-auto text-xl text-neutral-600">
              Our platform combines security, privacy, and advanced analytics to transform healthcare data management.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, i) => (
              <motion.div
                key={i}
                className="bg-white p-6 rounded-xl border border-neutral-200 hover:shadow-md transition-shadow"
                custom={i}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={fadeIn}
              >
                <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-lg font-semibold text-neutral-900 mb-2">{feature.title}</h3>
                <p className="text-neutral-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
      
      {/* How It Works */}
      <div className="py-16 bg-neutral-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-neutral-900">How It Works</h2>
            <p className="mt-4 max-w-2xl mx-auto text-xl text-neutral-600">
              Our secure process ensures your data remains private while enabling valuable health insights.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              className="bg-white p-6 rounded-xl shadow-sm relative"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <div className="absolute top-0 left-0 transform -translate-x-1/3 -translate-y-1/3 bg-primary-500 w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-xl">
                1
              </div>
              <h3 className="text-lg font-semibold text-neutral-900 mb-4">Data Collection & Classification</h3>
              <p className="text-neutral-600">
                Enter your health and personal information. Our system automatically classifies data as personal or health-related.
              </p>
              <div className="mt-4 p-3 bg-primary-50 rounded-lg">
                <div className="flex items-center text-sm text-primary-700">
                  <Lock className="h-4 w-4 mr-2" />
                  Personal data is encrypted with AES-256 using a unique key for each user
                </div>
              </div>
            </motion.div>
            
            <motion.div 
              className="bg-white p-6 rounded-xl shadow-sm relative"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <div className="absolute top-0 left-0 transform -translate-x-1/3 -translate-y-1/3 bg-primary-500 w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-xl">
                2
              </div>
              <h3 className="text-lg font-semibold text-neutral-900 mb-4">ML Analysis & Insights</h3>
              <p className="text-neutral-600">
                Machine learning models analyze your health data to provide personalized insights and risk assessments.
              </p>
              <div className="mt-4 p-3 bg-primary-50 rounded-lg">
                <div className="flex items-center text-sm text-primary-700">
                  <Brain className="h-4 w-4 mr-2" />
                  ML models only work with health data, never with your personal information
                </div>
              </div>
            </motion.div>
            
            <motion.div 
              className="bg-white p-6 rounded-xl shadow-sm relative"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              viewport={{ once: true }}
            >
              <div className="absolute top-0 left-0 transform -translate-x-1/3 -translate-y-1/3 bg-primary-500 w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-xl">
                3
              </div>
              <h3 className="text-lg font-semibold text-neutral-900 mb-4">Secure Sharing & Access</h3>
              <p className="text-neutral-600">
                Healthcare providers can access only your health data when needed while personal details remain private.
              </p>
              <div className="mt-4 p-3 bg-primary-50 rounded-lg">
                <div className="flex items-center text-sm text-primary-700">
                  <Shield className="h-4 w-4 mr-2" />
                  Role-based access control ensures hospitals only see what they need
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
      
      {/* CTA Section */}
      <div className="bg-primary-600 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-white">Ready to secure your health data?</h2>
            <p className="mt-4 max-w-2xl mx-auto text-xl text-primary-100">
              Join HealthSecure today and experience healthcare with privacy by design.
            </p>
            <div className="mt-8">
              <Link to="/register">
                <Button 
                  size="lg" 
                  className="bg-white text-primary-700 hover:bg-primary-50"
                >
                  Get Started Now
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Home;