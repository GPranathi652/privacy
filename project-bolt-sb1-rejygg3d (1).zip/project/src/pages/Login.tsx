import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { Mail, Lock, Shield } from 'lucide-react';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import { Card, CardHeader, CardBody, CardFooter } from '../components/ui/Card';
import Alert from '../components/ui/Alert';
import { useAuth } from '../contexts/AuthContext';
import Layout from '../components/layout/Layout';

interface LoginFormData {
  email: string;
  password: string;
}

const Login: React.FC = () => {
  const { register, handleSubmit, formState: { errors } } = useForm<LoginFormData>();
  const { login, state, clearError } = useAuth();
  const navigate = useNavigate();
  const [rememberMe, setRememberMe] = useState(false);
  
  const onSubmit = async (data: LoginFormData) => {
    await login(data.email, data.password);
    
    // Redirect after successful login
    if (!state.error) {
      navigate('/dashboard');
    }
  };
  
  return (
    <Layout>
      <div className="flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 animate-entrance">
        <div className="max-w-md w-full space-y-8">
          <div className="text-center">
            <div className="flex justify-center">
              <Shield className="h-12 w-12 text-primary-600" />
            </div>
            <h1 className="mt-4 text-3xl font-extrabold text-neutral-900">
              Welcome back
            </h1>
            <p className="mt-2 text-sm text-neutral-600">
              Sign in to your HealthSecure account
            </p>
          </div>
          
          <Card>
            <CardBody>
              {state.error && (
                <Alert 
                  variant="error" 
                  title="Login Failed" 
                  onClose={clearError}
                >
                  {state.error}
                </Alert>
              )}
              
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                <div>
                  <Input
                    id="email"
                    type="email"
                    label="Email address"
                    leftIcon={<Mail size={18} />}
                    error={errors.email?.message}
                    {...register('email', { 
                      required: 'Email is required',
                      pattern: {
                        value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                        message: 'Invalid email address',
                      }
                    })}
                  />
                </div>
                
                <div>
                  <Input
                    id="password"
                    type="password"
                    label="Password"
                    leftIcon={<Lock size={18} />}
                    error={errors.password?.message}
                    {...register('password', { 
                      required: 'Password is required',
                      minLength: {
                        value: 6,
                        message: 'Password must be at least 6 characters',
                      }
                    })}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <input
                      id="remember-me"
                      name="remember-me"
                      type="checkbox"
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-neutral-300 rounded"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                    />
                    <label htmlFor="remember-me" className="ml-2 block text-sm text-neutral-700">
                      Remember me
                    </label>
                  </div>
                  
                  <div className="text-sm">
                    <Link to="/forgot-password" className="font-medium text-primary-600 hover:text-primary-500">
                      Forgot your password?
                    </Link>
                  </div>
                </div>
                
                <Button
                  type="submit"
                  fullWidth
                  isLoading={state.isLoading}
                >
                  Sign in
                </Button>
              </form>
            </CardBody>
            <CardFooter className="flex justify-center">
              <p className="text-sm text-neutral-600">
                Don&apos;t have an account?{' '}
                <Link to="/register" className="font-medium text-primary-600 hover:text-primary-500">
                  Sign up
                </Link>
              </p>
            </CardFooter>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Login;