import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Activity, Heart, Droplet, Thermometer, Wind, UserCheck, PlusCircle } from 'lucide-react';
import Button from '../components/ui/Button';
import { Card, CardHeader, CardBody } from '../components/ui/Card';
import Layout from '../components/layout/Layout';
import { useAuth } from '../contexts/AuthContext';
import { HealthData, MLPrediction } from '../types';
import api from '../utils/api';

const Dashboard: React.FC = () => {
  const { state } = useAuth();
  const navigate = useNavigate();
  const [healthData, setHealthData] = useState<HealthData | null>(null);
  const [predictions, setPredictions] = useState<MLPrediction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    if (!state.isAuthenticated) {
      navigate('/login');
      return;
    }
    
    const fetchData = async () => {
      try {
        setIsLoading(true);
        // In a real app, these would be actual API calls
        // Simulating API responses for demo purposes
        setTimeout(() => {
          setHealthData({
            id: '123',
            userId: state.user?.id || '',
            bloodPressure: '120/80',
            heartRate: 72,
            temperature: 36.6,
            respiratoryRate: 16,
            oxygenSaturation: 98,
            glucose: 90,
            symptoms: 'None',
            medications: ['Vitamin D'],
            allergies: ['Pollen'],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          });
          
          setPredictions([
            {
              condition: 'Diabetes Risk',
              probability: 0.12,
              riskLevel: 'low',
              recommendations: [
                'Maintain a healthy diet',
                'Regular exercise',
                'Annual checkups'
              ]
            },
            {
              condition: 'Hypertension',
              probability: 0.23,
              riskLevel: 'medium',
              recommendations: [
                'Monitor blood pressure',
                'Reduce sodium intake',
                'Regular cardio exercise'
              ]
            }
          ]);
          
          setIsLoading(false);
        }, 1000);
      } catch (error) {
        console.error('Error fetching data', error);
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, [state.isAuthenticated, navigate, state.user]);
  
  if (!state.isAuthenticated) {
    return null;
  }
  
  const renderVitalCard = (
    icon: React.ReactNode, 
    title: string, 
    value: string | number, 
    unit: string,
    color: string = 'primary'
  ) => {
    return (
      <Card className="transform transition-all hover:scale-105">
        <CardBody className="flex items-center">
          <div className={`p-3.5 rounded-full bg-${color}-100 text-${color}-700 mr-4`}>
            {icon}
          </div>
          <div>
            <p className="text-sm text-neutral-500">{title}</p>
            <div className="flex items-baseline">
              <h3 className="text-2xl font-bold text-neutral-900">{value}</h3>
              <span className="ml-1 text-neutral-500">{unit}</span>
            </div>
          </div>
        </CardBody>
      </Card>
    );
  };
  
  const getRiskBadgeColor = (risk: 'low' | 'medium' | 'high') => {
    switch (risk) {
      case 'low':
        return 'bg-success-100 text-success-800';
      case 'medium':
        return 'bg-warning-100 text-warning-800';
      case 'high':
        return 'bg-error-100 text-error-800';
      default:
        return 'bg-neutral-100 text-neutral-800';
    }
  };
  
  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">Health Dashboard</h1>
            <p className="text-neutral-600">Monitor your health vitals and predictive insights</p>
          </div>
          
          <div className="mt-4 md:mt-0 flex space-x-3">
            <Button
              variant="outline"
              leftIcon={<Activity size={18} />}
              onClick={() => navigate('/health-records')}
            >
              View Health Records
            </Button>
            <Button
              leftIcon={<PlusCircle size={18} />}
              onClick={() => navigate('/add-health-data')}
            >
              Add New Data
            </Button>
          </div>
        </div>
        
        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
          </div>
        ) : (
          <>
            {/* Vitals Section */}
            <Card className="mb-8">
              <CardHeader>
                <h2 className="text-lg font-semibold text-neutral-900">Current Health Vitals</h2>
              </CardHeader>
              <CardBody>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {healthData && (
                    <>
                      {renderVitalCard(
                        <Heart size={24} />, 
                        'Heart Rate', 
                        healthData.heartRate, 
                        'bpm'
                      )}
                      {renderVitalCard(
                        <Droplet size={24} />, 
                        'Blood Pressure', 
                        healthData.bloodPressure, 
                        'mmHg'
                      )}
                      {renderVitalCard(
                        <Thermometer size={24} />, 
                        'Body Temperature', 
                        healthData.temperature, 
                        '°C',
                        'secondary'
                      )}
                      {renderVitalCard(
                        <Wind size={24} />, 
                        'Respiratory Rate', 
                        healthData.respiratoryRate, 
                        'bpm',
                        'secondary'
                      )}
                      {renderVitalCard(
                        <Activity size={24} />, 
                        'Oxygen Saturation', 
                        healthData.oxygenSaturation, 
                        '%',
                        'accent'
                      )}
                      {renderVitalCard(
                        <Droplet size={24} />, 
                        'Glucose Level', 
                        healthData.glucose, 
                        'mg/dL',
                        'accent'
                      )}
                    </>
                  )}
                </div>
              </CardBody>
            </Card>
            
            {/* Predictions Section */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <h2 className="text-lg font-semibold text-neutral-900">Health Predictions</h2>
                </CardHeader>
                <CardBody>
                  {predictions.length > 0 ? (
                    <div className="space-y-4">
                      {predictions.map((prediction, index) => (
                        <div 
                          key={index} 
                          className="p-4 border rounded-lg bg-neutral-50 hover:shadow-sm transition-shadow"
                        >
                          <div className="flex justify-between items-start mb-2">
                            <h3 className="font-medium text-neutral-900">{prediction.condition}</h3>
                            <span 
                              className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getRiskBadgeColor(prediction.riskLevel)}`}
                            >
                              {prediction.riskLevel.charAt(0).toUpperCase() + prediction.riskLevel.slice(1)} Risk
                            </span>
                          </div>
                          <div className="w-full bg-neutral-200 rounded-full h-2.5 mb-4">
                            <div 
                              className={`h-2.5 rounded-full ${
                                prediction.riskLevel === 'low' 
                                  ? 'bg-success-500' 
                                  : prediction.riskLevel === 'medium'
                                    ? 'bg-warning-500'
                                    : 'bg-error-500'
                              }`}
                              style={{ width: `${prediction.probability * 100}%` }}
                            ></div>
                          </div>
                          <div>
                            <h4 className="text-sm font-medium text-neutral-700 mb-2">Recommendations:</h4>
                            <ul className="text-sm text-neutral-600 space-y-1">
                              {prediction.recommendations.map((rec, idx) => (
                                <li key={idx} className="flex items-start">
                                  <span className="text-primary-500 mr-2">•</span>
                                  {rec}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6">
                      <p className="text-neutral-600">No predictions available yet.</p>
                    </div>
                  )}
                </CardBody>
              </Card>
              
              <Card>
                <CardHeader>
                  <h2 className="text-lg font-semibold text-neutral-900">Health Insights</h2>
                </CardHeader>
                <CardBody>
                  <div className="bg-primary-50 border border-primary-100 rounded-lg p-4 mb-4">
                    <div className="flex">
                      <UserCheck className="h-5 w-5 text-primary-600 mr-2" />
                      <h3 className="font-medium text-primary-800">Your health data looks good</h3>
                    </div>
                    <p className="mt-2 text-sm text-primary-700">
                      All vitals are within normal ranges. Continue maintaining your healthy habits.
                    </p>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="p-4 border rounded-lg hover:shadow-sm transition-shadow">
                      <h3 className="font-medium text-neutral-900 mb-2">Activity Suggestion</h3>
                      <p className="text-sm text-neutral-600">
                        Based on your profile, we recommend 30 minutes of moderate activity 5 days a week.
                      </p>
                    </div>
                    
                    <div className="p-4 border rounded-lg hover:shadow-sm transition-shadow">
                      <h3 className="font-medium text-neutral-900 mb-2">Nutrition Tip</h3>
                      <p className="text-sm text-neutral-600">
                        Including more leafy greens may help maintain your blood pressure and overall cardiovascular health.
                      </p>
                    </div>
                    
                    <div className="p-4 border rounded-lg hover:shadow-sm transition-shadow">
                      <h3 className="font-medium text-neutral-900 mb-2">Upcoming Check-up</h3>
                      <p className="text-sm text-neutral-600">
                        Consider scheduling your annual health check-up in the next 2 months.
                      </p>
                    </div>
                  </div>
                </CardBody>
              </Card>
            </div>
          </>
        )}
      </div>
    </Layout>
  );
};

export default Dashboard;