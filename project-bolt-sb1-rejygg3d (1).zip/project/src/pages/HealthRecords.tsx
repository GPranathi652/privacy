import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Activity, Heart, Thermometer, Droplet, Wind, PlusCircle, AlertCircle } from 'lucide-react';
import Layout from '../components/layout/Layout';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import { Card, CardHeader, CardBody } from '../components/ui/Card';
import { useAuth } from '../contexts/AuthContext';
import { HealthData } from '../types';
import api from '../utils/api';
import { toast } from 'react-toastify';

const HealthRecords: React.FC = () => {
  const { state } = useAuth();
  const navigate = useNavigate();
  const [healthRecords, setHealthRecords] = useState<HealthData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAddingRecord, setIsAddingRecord] = useState(false);
  const [newRecord, setNewRecord] = useState({
    bloodPressure: '',
    heartRate: '',
    temperature: '',
    respiratoryRate: '',
    oxygenSaturation: '',
    glucose: '',
    symptoms: '',
    medications: '',
    allergies: ''
  });

  useEffect(() => {
    if (!state.isAuthenticated) {
      navigate('/login');
      return;
    }
    fetchHealthRecords();
  }, [state.isAuthenticated, navigate]);

  const fetchHealthRecords = async () => {
    try {
      setIsLoading(true);
      const response = await api.get(`/health-data/${state.user?.id}`);
      if (response.data.success) {
        setHealthRecords(response.data.data);
      }
    } catch (error) {
      console.error('Error fetching health records:', error);
      toast.error('Failed to fetch health records');
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setNewRecord(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const formattedRecord = {
        user_id: state.user?.id,
        blood_pressure: newRecord.bloodPressure,
        heart_rate: parseInt(newRecord.heartRate),
        temperature: parseFloat(newRecord.temperature),
        respiratory_rate: parseInt(newRecord.respiratoryRate),
        oxygen_saturation: parseInt(newRecord.oxygenSaturation),
        glucose: parseInt(newRecord.glucose),
        symptoms: newRecord.symptoms,
        medications: newRecord.medications.split(',').map(med => med.trim()),
        allergies: newRecord.allergies.split(',').map(allergy => allergy.trim())
      };

      const response = await api.post('/health-data', formattedRecord);
      if (response.data.success) {
        toast.success('Health record added successfully');
        setIsAddingRecord(false);
        setNewRecord({
          bloodPressure: '',
          heartRate: '',
          temperature: '',
          respiratoryRate: '',
          oxygenSaturation: '',
          glucose: '',
          symptoms: '',
          medications: '',
          allergies: ''
        });
        fetchHealthRecords();
      }
    } catch (error) {
      console.error('Error adding health record:', error);
      toast.error('Failed to add health record');
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">Health Records</h1>
            <p className="text-neutral-600">View and manage your health data</p>
          </div>
          <Button
            onClick={() => setIsAddingRecord(!isAddingRecord)}
            leftIcon={isAddingRecord ? <AlertCircle size={18} /> : <PlusCircle size={18} />}
          >
            {isAddingRecord ? 'Cancel' : 'Add New Record'}
          </Button>
        </div>

        {isAddingRecord && (
          <Card className="mb-8">
            <CardHeader>
              <h2 className="text-lg font-semibold">Add New Health Record</h2>
            </CardHeader>
            <CardBody>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Input
                    label="Blood Pressure"
                    name="bloodPressure"
                    value={newRecord.bloodPressure}
                    onChange={handleInputChange}
                    placeholder="120/80"
                    required
                    leftIcon={<Heart size={18} />}
                    dataCategory="health"
                  />
                  <Input
                    label="Heart Rate"
                    name="heartRate"
                    type="number"
                    value={newRecord.heartRate}
                    onChange={handleInputChange}
                    placeholder="72"
                    required
                    leftIcon={<Activity size={18} />}
                    dataCategory="health"
                  />
                  <Input
                    label="Temperature (°C)"
                    name="temperature"
                    type="number"
                    step="0.1"
                    value={newRecord.temperature}
                    onChange={handleInputChange}
                    placeholder="36.6"
                    required
                    leftIcon={<Thermometer size={18} />}
                    dataCategory="health"
                  />
                  <Input
                    label="Respiratory Rate"
                    name="respiratoryRate"
                    type="number"
                    value={newRecord.respiratoryRate}
                    onChange={handleInputChange}
                    placeholder="16"
                    required
                    leftIcon={<Wind size={18} />}
                    dataCategory="health"
                  />
                  <Input
                    label="Oxygen Saturation (%)"
                    name="oxygenSaturation"
                    type="number"
                    value={newRecord.oxygenSaturation}
                    onChange={handleInputChange}
                    placeholder="98"
                    required
                    leftIcon={<Activity size={18} />}
                    dataCategory="health"
                  />
                  <Input
                    label="Glucose (mg/dL)"
                    name="glucose"
                    type="number"
                    value={newRecord.glucose}
                    onChange={handleInputChange}
                    placeholder="90"
                    required
                    leftIcon={<Droplet size={18} />}
                    dataCategory="health"
                  />
                </div>
                <div className="space-y-4">
                  <Input
                    label="Symptoms"
                    name="symptoms"
                    value={newRecord.symptoms}
                    onChange={handleInputChange}
                    placeholder="Enter any symptoms"
                    dataCategory="health"
                  />
                  <Input
                    label="Medications"
                    name="medications"
                    value={newRecord.medications}
                    onChange={handleInputChange}
                    placeholder="Enter medications (comma-separated)"
                    helpText="Separate multiple medications with commas"
                    dataCategory="health"
                  />
                  <Input
                    label="Allergies"
                    name="allergies"
                    value={newRecord.allergies}
                    onChange={handleInputChange}
                    placeholder="Enter allergies (comma-separated)"
                    helpText="Separate multiple allergies with commas"
                    dataCategory="health"
                  />
                </div>
                <div className="flex justify-end space-x-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsAddingRecord(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit">
                    Save Record
                  </Button>
                </div>
              </form>
            </CardBody>
          </Card>
        )}

        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
          </div>
        ) : healthRecords.length > 0 ? (
          <div className="space-y-6">
            {healthRecords.map((record, index) => (
              <Card key={record.id} className="hover:shadow-md transition-shadow">
                <CardBody>
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-lg font-semibold text-neutral-900">
                      Health Record #{healthRecords.length - index}
                    </h3>
                    <span className="text-sm text-neutral-500">
                      {formatDate(record.createdAt)}
                    </span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="flex items-center space-x-2">
                      <Heart className="text-primary-500" size={18} />
                      <span className="text-neutral-600">Blood Pressure:</span>
                      <span className="font-medium">{record.bloodPressure}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Activity className="text-primary-500" size={18} />
                      <span className="text-neutral-600">Heart Rate:</span>
                      <span className="font-medium">{record.heartRate} bpm</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Thermometer className="text-primary-500" size={18} />
                      <span className="text-neutral-600">Temperature:</span>
                      <span className="font-medium">{record.temperature}°C</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Wind className="text-primary-500" size={18} />
                      <span className="text-neutral-600">Respiratory Rate:</span>
                      <span className="font-medium">{record.respiratoryRate} bpm</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Activity className="text-primary-500" size={18} />
                      <span className="text-neutral-600">O2 Saturation:</span>
                      <span className="font-medium">{record.oxygenSaturation}%</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Droplet className="text-primary-500" size={18} />
                      <span className="text-neutral-600">Glucose:</span>
                      <span className="font-medium">{record.glucose} mg/dL</span>
                    </div>
                  </div>
                  {record.symptoms && (
                    <div className="mt-4">
                      <h4 className="font-medium text-neutral-900">Symptoms</h4>
                      <p className="text-neutral-600">{record.symptoms}</p>
                    </div>
                  )}
                  {record.medications.length > 0 && (
                    <div className="mt-4">
                      <h4 className="font-medium text-neutral-900">Medications</h4>
                      <div className="flex flex-wrap gap-2">
                        {record.medications.map((med, i) => (
                          <span
                            key={i}
                            className="px-2 py-1 bg-primary-50 text-primary-700 rounded-md text-sm"
                          >
                            {med}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                  {record.allergies.length > 0 && (
                    <div className="mt-4">
                      <h4 className="font-medium text-neutral-900">Allergies</h4>
                      <div className="flex flex-wrap gap-2">
                        {record.allergies.map((allergy, i) => (
                          <span
                            key={i}
                            className="px-2 py-1 bg-error-50 text-error-700 rounded-md text-sm"
                          >
                            {allergy}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </CardBody>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardBody className="text-center py-12">
              <div className="flex flex-col items-center">
                <Activity className="h-12 w-12 text-neutral-400 mb-4" />
                <h3 className="text-lg font-medium text-neutral-900 mb-2">No Health Records</h3>
                <p className="text-neutral-600 mb-6">
                  Start tracking your health by adding your first record
                </p>
                <Button
                  onClick={() => setIsAddingRecord(true)}
                  leftIcon={<Plus size={18} />}
                >
                  Add Health Record
                </Button>
              </div>
            </CardBody>
          </Card>
        )}
      </div>
    </Layout>
  );
};

export default HealthRecords;