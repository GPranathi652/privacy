import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { Mail, Lock, User, Shield, Building } from 'lucide-react';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import { Card, CardHeader, CardBody, CardFooter } from '../components/ui/Card';
import Alert from '../components/ui/Alert';
import { useAuth } from '../contexts/AuthContext';
import Layout from '../components/layout/Layout';
import { UserRole } from '../types';

interface RegisterFormData {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
}

const Register: React.FC = () => {
  const { register, handleSubmit, watch, formState: { errors } } = useForm<RegisterFormData>();
  const { register: registerUser, state, clearError } = useAuth();
  const navigate = useNavigate();
  const [role, setRole] = useState<UserRole>('User');
  
  const password = watch('password');
  
  const onSubmit = async (data: RegisterFormData) => {
    await registerUser(data.email, data.password, data.name, role);
    
    if (!state.error) {
      navigate('/login');
    }
  };
  
  return (
    <Layout>
      <div className="flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 animate-entrance">
        <div className="max-w-md w-full space-y-8">
          <div className="text-center">
            <div className="flex justify-center">
              <Shield className="h-12 w-12 text-primary-600" />
            </div>
            <h1 className="mt-4 text-3xl font-extrabold text-neutral-900">
              Create an account
            </h1>
            <p className="mt-2 text-sm text-neutral-600">
              Join HealthSecure and take control of your health data
            </p>
          </div>
          
          <Card>
            <CardBody>
              {state.error && (
                <Alert 
                  variant="error" 
                  title="Registration Failed" 
                  onClose={clearError}
                >
                  {state.error}
                </Alert>
              )}
              
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                <div>
                  <Input
                    id="name"
                    type="text"
                    label="Full Name"
                    leftIcon={<User size={18} />}
                    error={errors.name?.message}
                    {...register('name', { 
                      required: 'Full name is required',
                      minLength: {
                        value: 2,
                        message: 'Name must be at least 2 characters',
                      }
                    })}
                  />
                </div>
                
                <div>
                  <Input
                    id="email"
                    type="email"
                    label="Email address"
                    leftIcon={<Mail size={18} />}
                    error={errors.email?.message}
                    {...register('email', { 
                      required: 'Email is required',
                      pattern: {
                        value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                        message: 'Invalid email address',
                      }
                    })}
                  />
                </div>
                
                <div>
                  <Input
                    id="password"
                    type="password"
                    label="Password"
                    leftIcon={<Lock size={18} />}
                    error={errors.password?.message}
                    helpText="Must be at least 8 characters with letters and numbers"
                    {...register('password', { 
                      required: 'Password is required',
                      minLength: {
                        value: 8,
                        message: 'Password must be at least 8 characters',
                      },
                      pattern: {
                        value: /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*#?&]{8,}$/,
                        message: 'Password must contain at least one letter and one number',
                      }
                    })}
                  />
                </div>
                
                <div>
                  <Input
                    id="confirmPassword"
                    type="password"
                    label="Confirm Password"
                    leftIcon={<Lock size={18} />}
                    error={errors.confirmPassword?.message}
                    {...register('confirmPassword', { 
                      required: 'Please confirm your password',
                      validate: value => value === password || 'Passwords do not match'
                    })}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-neutral-700 mb-1">
                    Account Type
                  </label>
                  <div className="flex space-x-4">
                    <div 
                      className={`flex-1 p-3 border rounded-md cursor-pointer transition-all ${
                        role === 'User' 
                          ? 'border-primary-500 bg-primary-50 text-primary-700' 
                          : 'border-neutral-300 bg-white hover:bg-neutral-50'
                      }`}
                      onClick={() => setRole('User')}
                    >
                      <div className="flex items-center mb-1">
                        <User size={18} className={role === 'User' ? 'text-primary-600' : 'text-neutral-500'} />
                        <span className="ml-2 font-medium">Patient</span>
                      </div>
                      <p className="text-xs text-neutral-600">For individuals managing personal health data</p>
                    </div>
                    
                    <div 
                      className={`flex-1 p-3 border rounded-md cursor-pointer transition-all ${
                        role === 'Hospital' 
                          ? 'border-primary-500 bg-primary-50 text-primary-700' 
                          : 'border-neutral-300 bg-white hover:bg-neutral-50'
                      }`}
                      onClick={() => setRole('Hospital')}
                    >
                      <div className="flex items-center mb-1">
                        <Building size={18} className={role === 'Hospital' ? 'text-primary-600' : 'text-neutral-500'} />
                        <span className="ml-2 font-medium">Hospital</span>
                      </div>
                      <p className="text-xs text-neutral-600">For healthcare providers and institutions</p>
                    </div>
                  </div>
                </div>
                
                <Button
                  type="submit"
                  fullWidth
                  isLoading={state.isLoading}
                >
                  Create Account
                </Button>
              </form>
            </CardBody>
            <CardFooter className="flex justify-center">
              <p className="text-sm text-neutral-600">
                Already have an account?{' '}
                <Link to="/login" className="font-medium text-primary-600 hover:text-primary-500">
                  Sign in
                </Link>
              </p>
            </CardFooter>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Register;