/**
 * Utility functions for client-side encryption and decryption
 * Note: In a real application, the encryption should primarily happen on the server
 * This is a simplified version for demonstration purposes
 */

// Generate a user-specific encryption key based on user ID and a server-provided salt
export const generateUserKey = async (userId: string, salt: string): Promise<CryptoKey> => {
  const encoder = new TextEncoder();
  const keyMaterial = await window.crypto.subtle.importKey(
    'raw',
    encoder.encode(`${userId}:${salt}`),
    { name: 'PBKDF2' },
    false,
    ['deriveBits', 'deriveKey']
  );

  return window.crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: encoder.encode(salt),
      iterations: 100000,
      hash: 'SHA-256',
    },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
};

// Encrypt data
export const encryptData = async (data: string, key: CryptoKey): Promise<string> => {
  const encoder = new TextEncoder();
  const iv = window.crypto.getRandomValues(new Uint8Array(12));
  
  const encryptedData = await window.crypto.subtle.encrypt(
    {
      name: 'AES-GCM',
      iv: iv,
    },
    key,
    encoder.encode(data)
  );
  
  // Combine IV and encrypted data, and convert to base64
  const encryptedBuffer = new Uint8Array(iv.length + encryptedData.byteLength);
  encryptedBuffer.set(iv);
  encryptedBuffer.set(new Uint8Array(encryptedData), iv.length);
  
  return btoa(String.fromCharCode(...encryptedBuffer));
};

// Decrypt data
export const decryptData = async (encryptedData: string, key: CryptoKey): Promise<string> => {
  // Convert from base64 to array buffer
  const encryptedBytes = Uint8Array.from(atob(encryptedData), c => c.charCodeAt(0));
  
  // Extract IV and data
  const iv = encryptedBytes.slice(0, 12);
  const data = encryptedBytes.slice(12);
  
  const decryptedData = await window.crypto.subtle.decrypt(
    {
      name: 'AES-GCM',
      iv: iv,
    },
    key,
    data
  );
  
  return new TextDecoder().decode(decryptedData);
};

// Classify data fields as personal or health
export const classifyField = (fieldName: string): 'personal' | 'health' => {
  const personalFields = [
    'name', 'fullName', 'firstName', 'lastName', 'address', 'email', 
    'phone', 'phoneNumber', 'dateOfBirth', 'birthdate', 'gender', 
    'nationalId', 'ssn', 'insuranceId', 'emergencyContact'
  ];
  
  const healthFields = [
    'bloodPressure', 'heartRate', 'pulse', 'temperature', 'weight', 'height',
    'bmi', 'glucose', 'cholesterol', 'respiratoryRate', 'oxygenSaturation',
    'symptoms', 'diagnosis', 'allergies', 'medications', 'medicalHistory',
    'labResults', 'immunizations'
  ];
  
  const normalizedField = fieldName.toLowerCase();
  
  if (personalFields.some(field => normalizedField.includes(field.toLowerCase()))) {
    return 'personal';
  }
  
  if (healthFields.some(field => normalizedField.includes(field.toLowerCase()))) {
    return 'health';
  }
  
  // Default to personal for security (encrypt by default)
  return 'personal';
};