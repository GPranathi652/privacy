import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { Menu, X, User, LogOut, Shield, FileText, Activity, Home } from 'lucide-react';
import Button from '../ui/Button';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { state, logout } = useAuth();
  const location = useLocation();
  
  const toggleMenu = () => setIsOpen(!isOpen);
  
  const navLinks = [
    { name: 'Home', path: '/', icon: <Home size={18} /> },
    { name: 'Dashboard', path: '/dashboard', icon: <Activity size={18} /> },
    { name: 'Health Records', path: '/health-records', icon: <FileText size={18} /> },
  ];
  
  const isActive = (path: string) => location.pathname === path;
  
  return (
    <nav className="bg-white shadow">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <Link to="/" className="flex items-center">
                <Shield className="h-8 w-8 text-primary-600" />
                <span className="ml-2 text-xl font-semibold text-neutral-900">HealthSecure</span>
              </Link>
            </div>
            
            {/* Desktop navigation */}
            <div className="hidden sm:ml-6 sm:flex sm:space-x-4">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`inline-flex items-center px-3 py-2 text-sm font-medium rounded-md ${
                    isActive(link.path)
                      ? 'text-primary-600 bg-primary-50'
                      : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-50'
                  } transition-colors duration-150`}
                >
                  <span className="mr-1.5">{link.icon}</span>
                  {link.name}
                </Link>
              ))}
            </div>
          </div>
          
          {/* User section */}
          <div className="hidden sm:ml-6 sm:flex sm:items-center">
            {state.isAuthenticated ? (
              <div className="flex items-center">
                <Link
                  to="/profile"
                  className="inline-flex items-center px-3 py-2 text-sm font-medium text-neutral-600 hover:text-neutral-900 rounded-md hover:bg-neutral-50 transition-colors duration-150"
                >
                  <User size={18} className="mr-1.5" />
                  Profile
                </Link>
                <div className="border-l border-neutral-200 h-6 mx-3" />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={logout}
                  leftIcon={<LogOut size={16} />}
                >
                  Logout
                </Button>
              </div>
            ) : (
              <div className="flex items-center space-x-3">
                <Link to="/login">
                  <Button variant="outline" size="sm">Log in</Button>
                </Link>
                <Link to="/register">
                  <Button size="sm">Sign up</Button>
                </Link>
              </div>
            )}
          </div>
          
          {/* Mobile menu button */}
          <div className="flex items-center sm:hidden">
            <button
              type="button"
              className="inline-flex items-center justify-center p-2 rounded-md text-neutral-500 hover:text-neutral-600 hover:bg-neutral-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary-500"
              aria-expanded="false"
              onClick={toggleMenu}
            >
              <span className="sr-only">Open main menu</span>
              {isOpen ? (
                <X className="block h-6 w-6" aria-hidden="true" />
              ) : (
                <Menu className="block h-6 w-6" aria-hidden="true" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className={`sm:hidden ${isOpen ? 'block' : 'hidden'}`}>
        <div className="pt-2 pb-3 space-y-1">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={`block px-3 py-2 text-base font-medium ${
                isActive(link.path)
                  ? 'text-primary-600 bg-primary-50'
                  : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-50'
              } transition-colors duration-150`}
              onClick={() => setIsOpen(false)}
            >
              <div className="flex items-center">
                <span className="mr-2">{link.icon}</span>
                {link.name}
              </div>
            </Link>
          ))}
        </div>
        
        <div className="pt-4 pb-3 border-t border-neutral-200">
          {state.isAuthenticated ? (
            <>
              <Link
                to="/profile"
                className="block px-3 py-2 text-base font-medium text-neutral-600 hover:text-neutral-900 hover:bg-neutral-50"
                onClick={() => setIsOpen(false)}
              >
                <div className="flex items-center">
                  <User size={18} className="mr-2" />
                  Profile
                </div>
              </Link>
              <button
                className="block w-full text-left px-3 py-2 text-base font-medium text-neutral-600 hover:text-neutral-900 hover:bg-neutral-50"
                onClick={() => {
                  logout();
                  setIsOpen(false);
                }}
              >
                <div className="flex items-center">
                  <LogOut size={18} className="mr-2" />
                  Logout
                </div>
              </button>
            </>
          ) : (
            <div className="px-3 py-2 flex flex-col space-y-2">
              <Link to="/login" onClick={() => setIsOpen(false)}>
                <Button variant="outline" fullWidth>Log in</Button>
              </Link>
              <Link to="/register" onClick={() => setIsOpen(false)}>
                <Button fullWidth>Sign up</Button>
              </Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;