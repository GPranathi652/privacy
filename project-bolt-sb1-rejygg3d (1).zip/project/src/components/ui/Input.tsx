import React, { forwardRef } from 'react';
import { clsx } from 'clsx';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  helpText?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  dataCategory?: 'personal' | 'health' | null;
}

const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ 
    className,
    label,
    error,
    helpText,
    leftIcon,
    rightIcon,
    dataCategory,
    id,
    ...props 
  }, ref) => {
    const inputId = id || label?.toLowerCase().replace(/\s+/g, '-');
    
    const baseStyles = 'w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-1';
    const errorStyles = error ? 'border-error-500 focus:ring-error-500 focus:border-error-500' : 'border-neutral-300 focus:ring-primary-500 focus:border-primary-500';
    const iconStyles = leftIcon ? 'pl-10' : '';
    
    // Data category badge
    const renderDataBadge = () => {
      if (!dataCategory) return null;
      
      const badgeClasses = clsx(
        'inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ml-2',
        dataCategory === 'personal' 
          ? 'bg-accent-100 text-accent-800 encrypted-badge' 
          : 'bg-secondary-100 text-secondary-800 health-badge'
      );

      return (
        <span className={badgeClasses}>
          {dataCategory === 'personal' ? 'Encrypted' : 'Health'}
        </span>
      );
    };
    
    return (
      <div className="w-full">
        {label && (
          <div className="flex items-center mb-1">
            <label htmlFor={inputId} className="block text-sm font-medium text-neutral-700">
              {label}
            </label>
            {renderDataBadge()}
          </div>
        )}
        
        <div className="relative">
          {leftIcon && (
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-neutral-500">
              {leftIcon}
            </div>
          )}
          
          <input
            ref={ref}
            id={inputId}
            className={clsx(baseStyles, errorStyles, iconStyles, className)}
            aria-invalid={!!error}
            aria-describedby={error ? `${inputId}-error` : helpText ? `${inputId}-help` : undefined}
            {...props}
          />
          
          {rightIcon && (
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-neutral-500">
              {rightIcon}
            </div>
          )}
        </div>
        
        {error && (
          <p id={`${inputId}-error`} className="mt-1 text-sm text-error-600">
            {error}
          </p>
        )}
        
        {helpText && !error && (
          <p id={`${inputId}-help`} className="mt-1 text-sm text-neutral-500">
            {helpText}
          </p>
        )}
      </div>
    );
  }
);

Input.displayName = 'Input';

export default Input;