import React from 'react';
import { clsx } from 'clsx';
import { AlertCircle, CheckCircle, AlertTriangle, Info, XCircle } from 'lucide-react';

interface AlertProps {
  children: React.ReactNode;
  variant?: 'info' | 'success' | 'warning' | 'error';
  title?: string;
  onClose?: () => void;
  className?: string;
}

const Alert: React.FC<AlertProps> = ({ 
  children, 
  variant = 'info', 
  title,
  onClose,
  className 
}) => {
  const variantStyles = {
    info: {
      container: 'bg-primary-50 text-primary-800 border border-primary-200',
      icon: <Info className="h-5 w-5 text-primary-500" />,
    },
    success: {
      container: 'bg-success-50 text-success-800 border border-success-200',
      icon: <CheckCircle className="h-5 w-5 text-success-500" />,
    },
    warning: {
      container: 'bg-warning-50 text-warning-800 border border-warning-200',
      icon: <AlertTriangle className="h-5 w-5 text-warning-500" />,
    },
    error: {
      container: 'bg-error-50 text-error-800 border border-error-200',
      icon: <AlertCircle className="h-5 w-5 text-error-500" />,
    },
  };

  return (
    <div className={clsx('p-4 rounded-md mb-4', variantStyles[variant].container, className)}>
      <div className="flex items-start">
        <div className="flex-shrink-0 mt-0.5">
          {variantStyles[variant].icon}
        </div>
        <div className="ml-3 w-full">
          {title && (
            <h3 className="text-sm font-medium">
              {title}
            </h3>
          )}
          <div className={clsx('text-sm', title ? 'mt-1' : '')}>
            {children}
          </div>
        </div>
        {onClose && (
          <button
            type="button"
            className="ml-auto -mx-1.5 -my-1.5 rounded-md p-1.5 focus:outline-none focus:ring-2 focus:ring-offset-2"
            onClick={onClose}
          >
            <span className="sr-only">Dismiss</span>
            <XCircle className="h-5 w-5" />
          </button>
        )}
      </div>
    </div>
  );
};

export default Alert;