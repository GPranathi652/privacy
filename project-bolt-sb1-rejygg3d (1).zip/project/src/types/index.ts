// User types
export type UserRole = 'User' | 'Hospital';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

// Data types
export type DataCategory = 'personal' | 'health';

export interface HealthData {
  id: string;
  userId: string;
  bloodPressure: string;
  heartRate: number;
  temperature: number;
  respiratoryRate: number;
  oxygenSaturation: number;
  glucose: number;
  symptoms: string;
  medications: string[];
  allergies: string[];
  createdAt: string;
  updatedAt: string;
}

export interface PersonalData {
  id: string;
  userId: string;
  fullName: string;
  dateOfBirth: string;
  address: string;
  phoneNumber: string;
  emergencyContact: string;
  nationalId: string;
  insuranceId: string;
  createdAt: string;
  updatedAt: string;
}

export interface MLPrediction {
  condition: string;
  probability: number;
  riskLevel: 'low' | 'medium' | 'high';
  recommendations: string[];
}

// API response types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

export interface LoginResponse {
  token: string;
  user: User;
}

export interface RegisterResponse {
  success: boolean;
  message: string;
}