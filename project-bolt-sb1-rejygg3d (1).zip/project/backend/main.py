from fastapi import FastAPI, Depends, HTTPException, status, Security
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel, Field, EmailStr
from typing import Optional, List, Union, Dict, Any
from datetime import datetime, timedelta
from passlib.context import CryptContext
from jose import JWTError, jwt
import motor.motor_asyncio
import os
import secrets
from bson import ObjectId
from enum import Enum
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import joblib
import asyncio
from pymongo import MongoClient
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import base64

# Setup FastAPI app
app = FastAPI(title="HealthSecure API", 
              description="Secure Healthcare API with data classification and encryption",
              version="0.1.0")

# Configure CORS
origins = [
    "http://localhost:5173",  # Vite default development server
    "http://localhost:3000",
    "http://localhost:8000",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# MongoDB Connection
MONGO_URL = os.getenv("MONGO_URL", "mongodb://localhost:27017")
client = motor.motor_asyncio.AsyncIOMotorClient(MONGO_URL)
db = client.healthsecure

# Password and Security
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="api/auth/token")

# JWT Configuration
SECRET_KEY = os.getenv("SECRET_KEY", secrets.token_urlsafe(32))
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24  # 24 hours

# Models
class UserRole(str, Enum):
    USER = "User"
    HOSPITAL = "Hospital"

class PyObjectId(ObjectId):
    @classmethod
    def __get_validators__(cls):
        yield cls.validate

    @classmethod
    def validate(cls, v):
        if not ObjectId.is_valid(v):
            raise ValueError("Invalid ObjectId")
        return ObjectId(v)

    @classmethod
    def __modify_schema__(cls, field_schema):
        field_schema.update(type="string")

class UserBase(BaseModel):
    email: EmailStr
    name: str
    role: UserRole

class UserCreate(UserBase):
    password: str

class UserInDB(UserBase):
    id: PyObjectId = Field(default_factory=PyObjectId, alias="_id")
    hashed_password: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    encryption_salt: str

    class Config:
        allow_population_by_field_name = True
        arbitrary_types_allowed = True
        json_encoders = {ObjectId: str}

class User(UserBase):
    id: str

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: Optional[str] = None
    role: Optional[UserRole] = None

class DataCategory(str, Enum):
    PERSONAL = "personal"
    HEALTH = "health"

class HealthDataBase(BaseModel):
    user_id: str
    blood_pressure: str
    heart_rate: int
    temperature: float
    respiratory_rate: int
    oxygen_saturation: int
    glucose: int
    symptoms: str
    medications: List[str]
    allergies: List[str]

class HealthDataCreate(HealthDataBase):
    pass

class HealthDataInDB(HealthDataBase):
    id: PyObjectId = Field(default_factory=PyObjectId, alias="_id")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

    class Config:
        allow_population_by_field_name = True
        arbitrary_types_allowed = True
        json_encoders = {ObjectId: str}

class HealthData(HealthDataBase):
    id: str
    created_at: datetime
    updated_at: datetime

class PersonalDataBase(BaseModel):
    user_id: str
    full_name: str
    date_of_birth: str
    address: str
    phone_number: str
    emergency_contact: str
    national_id: str
    insurance_id: str
    encrypted: bool = True

class PersonalDataCreate(PersonalDataBase):
    pass

class PersonalDataInDB(PersonalDataBase):
    id: PyObjectId = Field(default_factory=PyObjectId, alias="_id")
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    # Store encrypted data - would contain the encrypted fields in a real implementation
    encrypted_data: str = ""
    iv: str = ""

    class Config:
        allow_population_by_field_name = True
        arbitrary_types_allowed = True
        json_encoders = {ObjectId: str}

class PersonalData(PersonalDataBase):
    id: str
    created_at: datetime
    updated_at: datetime

class MLPredictionBase(BaseModel):
    condition: str
    probability: float
    risk_level: str
    recommendations: List[str]

class MLPrediction(MLPredictionBase):
    user_id: str
    created_at: datetime = Field(default_factory=datetime.utcnow)

class ApiResponse(BaseModel):
    success: bool
    data: Optional[Any] = None
    error: Optional[str] = None

# Authentication and Security Functions
def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

async def get_user(email: str):
    user = await db.users.find_one({"email": email})
    if user:
        return UserInDB(**user)

async def authenticate_user(email: str, password: str):
    user = await get_user(email)
    if not user:
        return False
    if not verify_password(password, user.hashed_password):
        return False
    return user

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
        token_data = TokenData(username=username, role=payload.get("role"))
    except JWTError:
        raise credentials_exception
    user = await get_user(email=token_data.username)
    if user is None:
        raise credentials_exception
    return user

async def get_current_active_user(current_user: UserInDB = Depends(get_current_user)):
    return current_user

# Data Classification
def classify_field(field_name: str) -> DataCategory:
    personal_fields = [
        "name", "full_name", "first_name", "last_name", "address", "email", 
        "phone", "phone_number", "date_of_birth", "birthdate", "gender", 
        "national_id", "ssn", "insurance_id", "emergency_contact"
    ]
    
    health_fields = [
        "blood_pressure", "heart_rate", "pulse", "temperature", "weight", "height",
        "bmi", "glucose", "cholesterol", "respiratory_rate", "oxygen_saturation",
        "symptoms", "diagnosis", "allergies", "medications", "medical_history",
        "lab_results", "immunizations"
    ]
    
    normalized_field = field_name.lower()
    
    if any(field in normalized_field for field in personal_fields):
        return DataCategory.PERSONAL
    
    if any(field in normalized_field for field in health_fields):
        return DataCategory.HEALTH
    
    # Default to personal for security (encrypt by default)
    return DataCategory.PERSONAL

# Encryption utilities
def generate_encryption_key(user_id: str, salt: str) -> bytes:
    # In a real app, this would use a more sophisticated key derivation
    key_material = f"{user_id}:{salt}".encode()
    # Use a key derivation function in production
    # This is a simplified example
    return key_material[:32]  # AES-256 needs a 32-byte key

def encrypt_data(data: str, key: bytes) -> tuple[bytes, bytes]:
    # Generate a random 96-bit IV
    iv = os.urandom(12)
    
    # Create an AES-GCM cipher with the key
    cipher = AESGCM(key)
    
    # Encrypt the data
    encrypted_data = cipher.encrypt(iv, data.encode(), None)
    
    return encrypted_data, iv

def decrypt_data(encrypted_data: bytes, iv: bytes, key: bytes) -> str:
    cipher = AESGCM(key)
    decrypted_data = cipher.decrypt(iv, encrypted_data, None)
    return decrypted_data.decode()

# Endpoints
@app.get("/")
async def root():
    return {"message": "Welcome to HealthSecure API"}

# Auth routes
@app.post("/api/auth/register", response_model=ApiResponse)
async def register(user: UserCreate):
    # Check if user already exists
    existing_user = await db.users.find_one({"email": user.email})
    if existing_user:
        return ApiResponse(success=False, error="Email already registered")
    
    # Create new user
    salt = secrets.token_hex(16)
    user_dict = user.dict()
    hashed_password = get_password_hash(user.password)
    
    user_in_db = UserInDB(
        **{k: v for k, v in user_dict.items() if k != "password"},
        hashed_password=hashed_password,
        encryption_salt=salt
    )
    
    result = await db.users.insert_one(user_in_db.dict(by_alias=True))
    
    return ApiResponse(
        success=True,
        data={"message": "User registered successfully", "id": str(result.inserted_id)}
    )

@app.post("/api/auth/token", response_model=Token)
async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends()):
    user = await authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.email, "role": user.role, "id": str(user.id)},
        expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

@app.post("/api/auth/login", response_model=ApiResponse)
async def login(email: str, password: str):
    user = await authenticate_user(email, password)
    if not user:
        return ApiResponse(success=False, error="Invalid email or password")
    
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.email, "role": user.role, "id": str(user.id)},
        expires_delta=access_token_expires
    )
    
    return ApiResponse(
        success=True,
        data={
            "token": access_token,
            "user": {
                "id": str(user.id),
                "email": user.email,
                "name": user.name,
                "role": user.role
            }
        }
    )

# Health data routes
@app.post("/api/health-data", response_model=ApiResponse)
async def create_health_data(
    data: HealthDataCreate, 
    current_user: UserInDB = Depends(get_current_active_user)
):
    health_data = HealthDataInDB(**data.dict())
    result = await db.health_data.insert_one(health_data.dict(by_alias=True))
    
    # Train or update ML model with new data (in a real app this would be a background task)
    asyncio.create_task(update_ml_model())
    
    return ApiResponse(
        success=True,
        data={"id": str(result.inserted_id), "message": "Health data saved successfully"}
    )

@app.get("/api/health-data/{user_id}", response_model=ApiResponse)
async def get_health_data(
    user_id: str, 
    current_user: UserInDB = Depends(get_current_active_user)
):
    # Authorization check - users can see their own data, hospitals can see any health data
    if current_user.role == UserRole.USER and str(current_user.id) != user_id:
        return ApiResponse(success=False, error="Access denied")
    
    health_data = await db.health_data.find({"user_id": user_id}).to_list(None)
    
    return ApiResponse(
        success=True,
        data=[HealthData(**{**item, "id": str(item["_id"])}) for item in health_data]
    )

# Personal data routes
@app.post("/api/personal-data", response_model=ApiResponse)
async def create_personal_data(
    data: PersonalDataCreate, 
    current_user: UserInDB = Depends(get_current_active_user)
):
    # Only users can create personal data
    if current_user.role != UserRole.USER:
        return ApiResponse(success=False, error="Only users can create personal data")
    
    # Only users can create their own personal data
    if str(current_user.id) != data.user_id:
        return ApiResponse(success=False, error="You can only create your own personal data")
    
    # Encrypt the personal data
    encryption_key = generate_encryption_key(
        str(current_user.id),
        current_user.encryption_salt
    )
    
    # In a real app, we would encrypt all personal fields individually
    # For this example, we'll encrypt all personal data as JSON
    sensitive_data = {
        "full_name": data.full_name,
        "date_of_birth": data.date_of_birth,
        "address": data.address,
        "phone_number": data.phone_number,
        "emergency_contact": data.emergency_contact,
        "national_id": data.national_id,
        "insurance_id": data.insurance_id
    }
    
    import json
    json_data = json.dumps(sensitive_data)
    encrypted_data, iv = encrypt_data(json_data, encryption_key)
    
    # Convert binary data to base64 for storage
    b64_encrypted = base64.b64encode(encrypted_data).decode('utf-8')
    b64_iv = base64.b64encode(iv).decode('utf-8')
    
    personal_data = PersonalDataInDB(
        **data.dict(),
        encrypted_data=b64_encrypted,
        iv=b64_iv
    )
    
    result = await db.personal_data.insert_one(personal_data.dict(by_alias=True))
    
    return ApiResponse(
        success=True,
        data={"id": str(result.inserted_id), "message": "Personal data encrypted and saved successfully"}
    )

@app.get("/api/personal-data/{user_id}", response_model=ApiResponse)
async def get_personal_data(
    user_id: str, 
    current_user: UserInDB = Depends(get_current_active_user)
):
    # Authorization check - only users can see their own personal data
    if current_user.role != UserRole.USER or str(current_user.id) != user_id:
        return ApiResponse(success=False, error="Access denied")
    
    personal_data = await db.personal_data.find_one({"user_id": user_id})
    
    if not personal_data:
        return ApiResponse(success=False, error="Personal data not found")
    
    # Decrypt the data
    encryption_key = generate_encryption_key(
        str(current_user.id),
        current_user.encryption_salt
    )
    
    try:
        encrypted_data = base64.b64decode(personal_data["encrypted_data"])
        iv = base64.b64decode(personal_data["iv"])
        
        decrypted_json = decrypt_data(encrypted_data, iv, encryption_key)
        import json
        decrypted_data = json.loads(decrypted_json)
        
        # Replace the encrypted fields with decrypted values
        result = {**personal_data, **decrypted_data, "id": str(personal_data["_id"])}
        
        return ApiResponse(success=True, data=result)
    except Exception as e:
        return ApiResponse(success=False, error=f"Failed to decrypt data: {str(e)}")

# ML Prediction routes
@app.get("/api/predictions/{user_id}", response_model=ApiResponse)
async def get_predictions(
    user_id: str, 
    current_user: UserInDB = Depends(get_current_active_user)
):
    # Authorization check - users can see their own predictions, hospitals can see any predictions
    if current_user.role == UserRole.USER and str(current_user.id) != user_id:
        return ApiResponse(success=False, error="Access denied")
    
    # Get the user's health data
    health_data = await db.health_data.find({"user_id": user_id}).sort("created_at", -1).limit(1).to_list(None)
    
    if not health_data:
        return ApiResponse(success=False, error="No health data found for prediction")
    
    # In a real app, we'd use the ML model to generate predictions
    # For this example, we'll create sample predictions
    
    latest_data = health_data[0]
    
    # Simple rules-based predictions for demo
    predictions = []
    
    # Blood pressure check
    sys, dia = map(int, latest_data["blood_pressure"].split("/"))
    if sys > 140 or dia > 90:
        risk_level = "high" if (sys > 160 or dia > 100) else "medium"
        predictions.append(
            MLPrediction(
                condition="Hypertension",
                probability=0.7 if risk_level == "high" else 0.4,
                risk_level=risk_level,
                recommendations=[
                    "Monitor blood pressure regularly",
                    "Reduce sodium intake",
                    "Consult with a healthcare provider"
                ],
                user_id=user_id
            )
        )
    
    # Glucose check
    glucose = latest_data["glucose"]
    if glucose > 100:
        risk_level = "high" if glucose > 125 else "medium"
        predictions.append(
            MLPrediction(
                condition="Diabetes Risk",
                probability=0.8 if risk_level == "high" else 0.5,
                risk_level=risk_level,
                recommendations=[
                    "Monitor glucose levels",
                    "Maintain a healthy diet low in simple carbohydrates",
                    "Regular exercise",
                    "Consult with an endocrinologist"
                ],
                user_id=user_id
            )
        )
    
    # If no specific risks, add a general health prediction
    if not predictions:
        predictions.append(
            MLPrediction(
                condition="General Health",
                probability=0.9,
                risk_level="low",
                recommendations=[
                    "Continue maintaining healthy habits",
                    "Regular check-ups",
                    "Balanced diet and regular exercise"
                ],
                user_id=user_id
            )
        )
    
    return ApiResponse(
        success=True,
        data=predictions
    )

# ML Model functionality
async def update_ml_model():
    """Update the ML model with new health data (in a real app)"""
    # This is a placeholder for ML model training
    # In a real app, this would:
    # 1. Retrieve all health data
    # 2. Preprocess the data
    # 3. Train or update the ML model
    # 4. Save the model for future predictions
    
    print("ML model updated with new health data")
    return True

@app.on_event("startup")
async def startup_db_client():
    # Initialize database with dummy data if empty
    if await db.users.count_documents({}) == 0:
        # Create a test user
        test_user = UserInDB(
            email="user@example.com",
            name="Test User",
            role=UserRole.USER,
            hashed_password=get_password_hash("password123"),
            encryption_salt=secrets.token_hex(16)
        )
        await db.users.insert_one(test_user.dict(by_alias=True))
        
        # Create a test hospital
        test_hospital = UserInDB(
            email="hospital@example.com",
            name="Test Hospital",
            role=UserRole.HOSPITAL,
            hashed_password=get_password_hash("hospital123"),
            encryption_salt=secrets.token_hex(16)
        )
        await db.users.insert_one(test_hospital.dict(by_alias=True))
        
        print("Initialized database with test users")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)